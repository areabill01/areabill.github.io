﻿<?

		echo "<script>location.replace('index.php?http://vipmail2.mail.sina.com.cn/classic/index.php#action=maillist&fid=new&title=%25E6%2594%25B6%25E4%25BB%25B6%25E5%25A4%25B9');</script>";

?>